//Variables

//Getting data variables
let countriesData;
let countriesName = [];
let countriesIndicator = [];
let countriesYears = [];
let green = 0;
let red = 0;

//Line & bubble chart variables
let canvas;
let xDistance = 60;
let yDistance = 20;
let height = 800;
let width = 1000;

//Event Listeners
document.addEventListener("DOMContentLoaded", app);
document
    .getElementById("drawBubbleChart")
    .addEventListener("click", drawBubbleChart);
document.getElementById("drawSvgChart").addEventListener("click", drawSvgChart);
document.getElementById("drawTable").addEventListener("click", createTable);

// GETTING DATA FUNCTIONS

// Get data on page load
function app() {
    getData();
    getDataOptions();
    populateSelect();
}

//Getting data on page load
window.onload = () => {
    getData();
    getDataOptions();
    populateSelect();
};

// Get data from JSON
function getData() {
    fetch("./media/data.json")
        .then((response) => response.json())
        .then((data) => (countriesData = data));
}

//Setup data variables
function getDataOptions() {
    countriesYears = [...new Set(countriesData.map((country) => country.an))];
    countriesName = [...new Set(countriesData.map((country) => country.tara))];
    countriesIndicator = [
        ...new Set(countriesData.map((country) => country.indicator)),
    ];
}

// Populate Years dropdown
function addDropdown(element, array) {
    for (let i = 0; i < array.length; i++) {
        let opt = array[i];
        let el = document.createElement("option");
        el.textContent = opt;
        el.value = opt;
        element.appendChild(el);
    }
}

//Populate Country, Indicator and Year dropdowns
function populateSelect() {
    let selectCountry = document.getElementById("selectCountry");
    addDropdown(selectCountry, countriesName);
    let selectIndicator = document.getElementById("selectIndicator");
    addDropdown(selectIndicator, countriesIndicator);
    let selectYear = document.getElementById("selectTableYear");
    addDropdown(selectYear, countriesYears);
}

//Get Data by Year function
function getDataByYear(year) {
    console.log("Data from " + year);
    let dataByYear = [];
    countriesData.map((data) => {
        if (data.an === year) {
            dataByYear.push(data);
        }
    });
    return dataByYear;
}

//Get data by Year and country function
function getDataByYearAndCountry(year, country) {
    let dataByYearAndCountry = [];
    countriesData.map((data) => {
        if (data.an === year && data.tara === country)
            dataByYearAndCountry.push(data);
    });
    return dataByYearAndCountry;
}

//Get data by Indicator function
function getDataByIndicator(array, indicator) {
    let dataByIndicator = [];
    array.map((data) => {
        if (data.indicator === indicator) dataByIndicator.push(data);
    });

    return dataByIndicator;
}

//Get data by Country
function getDataByCountry(array, country) {
    let dataByCountry = [];
    array.map((data) => {
        if (data.tara === country) dataByCountry.push(data);
    });
    return dataByCountry;
}

// END OF GETTING DATA FUNCTIONS

// CREATING TABLE FUNCTIONS

//Create table
function createTable() {
    let selection = document.getElementById("selectTableYear");
    let selectedYear = selection.options[selection.selectedIndex].text;

    if(selectedYear!=='Select a year') {
        let tableContainer = document.querySelector(".tableContainer");
        while (tableContainer.hasChildNodes()) {
            tableContainer.removeChild(tableContainer.lastChild);
        }
        let title = document.createElement("div");
        title.className = "table-title";
        title.appendChild(document.createTextNode(`Table for year ${selectedYear} `));
        tableContainer.appendChild(title);
        let table = document.createElement("table");
        table.style.width = "100%";
        table.setAttribute("border", "1");
        let tableBody = document.createElement("tbody");
        let tr = table.insertRow();

        //Creating table Header
        createTableHeader(tr);

        //Inserting data into table
        const yearsData = getDataByYear(selectedYear);
        console.log("Years Data:", yearsData);
        yearsData.sort((a, b) => (a.tara > b.tara ? 1 : -1));
        console.log("Years data:", yearsData);
        insertDataIntoTable(yearsData, table, tr);

        table.appendChild(tableBody);
        tableContainer.appendChild(table);
    }
    else {
        alert('Please select a year!');

    }

}

//Create table function
function createTableHeader(tr) {
    let td = tr.insertCell();
    td.innerHTML = "Country";
    td = tr.insertCell();
    td.innerHTML = "PIB";
    td = tr.insertCell();
    td.innerHTML = "POP";
    td = tr.insertCell();
    td.innerHTML = "SV";
}

//Get mean of indicators
function getMeanIndicators(array) {
    let result = [
        { indicator: "PIB", valoare: 0 },
        { indicator: "POP", valoare: 0 },
        { indicator: "SV", valoare: 0 },
    ];
    result.map((element, index) => {
        let x = array.filter((el) => {
            return el.indicator === element.indicator;
        });
        let sum = 0;
        for (let i = 0; i < x.length; i++) {
            sum += x[i].valoare;
        }
        result[index].valoare = Math.round(sum / x.length);
    });

    return result;
}

//Insert data into table function
function insertDataIntoTable(array, table, tr) {
    let res = getMeanIndicators(array);
    let distanceFromMean = [
        { indicator: "PIB", valoare: 0 },
        { indicator: "POP", valoare: 0 },
        { indicator: "SV", valoare: 0 },
    ];
    let maxDistanceFromMean = [
        { indicator: "PIB", valoare: 0, unit: 0 },
        { indicator: "POP", valoare: 0, unit: 0 },
        { indicator: "SV", valoare: 0, unit: 0 },
    ];

    //Get Maximum Distance from mean function
    function getMaxDistanceFromMean() {
        let distanceFromMean = [
            { indicator: "PIB", valoare: 0 },
            { indicator: "POP", valoare: 0 },
            { indicator: "SV", valoare: 0 },
        ];
        for (let i = 0; i < array.length; i += 3) {
            for (let j = 0; j < 3; j++) {
                distanceFromMean[j].valoare = Math.round(
                    Math.abs(array[i].valoare - res[j].valoare)
                );
                distanceFromMean[j].valoare = Math.round(
                    Math.abs(array[i + 1].valoare - res[j].valoare)
                );
                distanceFromMean[j].valoare = Math.round(
                    Math.abs(array[i + 2].valoare - res[j].valoare)
                );
                if (distanceFromMean[j].valoare > maxDistanceFromMean[j].valoare)
                    maxDistanceFromMean[j].valoare = distanceFromMean[j].valoare;
            }
        }
        for (let j = 0; j < 3; j++) {
            maxDistanceFromMean[j].unit = maxDistanceFromMean[j].valoare / 510;
        }
    }

    getMaxDistanceFromMean();

    //Insert Table data and color according to mean distance function
    function insertTableDataAndColor(i, j, distanceFromMean) {
        td = tr.insertCell();
        distanceFromMean[j].valoare = Math.round(
            Math.abs(array[i].valoare - res[j].valoare)
        );
        let a = Math.abs(distanceFromMean[j].valoare) / maxDistanceFromMean[j].unit;
        if (a <= 255) {
            green = 255;
            red = a;
        } else {
            red = 255;
            green = a - red;
        }
        if(array[i].valoare) {
            td.style.color="black";
            td.style.backgroundColor = `rgb(${red},${green},0)`;
            td.innerHTML = array[i].valoare;
        }
        else {
            td.style.backgroundColor="rgb(255,0,0)";
            td.innerHTML='null';
        }

    }

    for (let i = 0; i < array.length; i += 3) {
        let j = 0;
        tr = table.insertRow();
        let td = tr.insertCell();
        td.innerHTML = array[i].tara;
        insertTableDataAndColor(i, j, distanceFromMean);
        insertTableDataAndColor(i + 1, j + 1, distanceFromMean);
        insertTableDataAndColor(i + 2, j + 2, distanceFromMean);
    }
}

// END OF CREATING TABLE FUNCTIONS

// CREATING BUBBLE CHART FUNCTIONS

function initializeLieGraph(array) {
    let ok=true;
    let e = document.getElementById("selectIndicator");
    let indicator = e.options[e.selectedIndex].text;
    if(indicator !== 'Select an indicator') {
        array = getDataByIndicator(countriesData, indicator);
    }
    else {
        alert('Please select an indicator!');
        ok=false;
    }
    e = document.getElementById("selectCountry");
    indicator = e.options[e.selectedIndex].text;
    if(indicator!=='Select a country') {
        array = getDataByCountry(array, indicator);
    }
    else {
        alert('Please select a country!');
        ok=false;
    }
    if(ok) {
        return array;
    }
    else  {
        return 0;
    }
}

function getMaxValue(array) {
    let max = 0;
    if (array && array.length) {
        for (let i = 0; i < array.length; i++) {
            if (array[i].valoare > max) max = array[i].valoare;
        }
        // max+=10-max%10;
    }
    return max + max / 100;
}

function getMinValue(array) {
    let min;
    if (array && array.length) {
        min = array[0].valoare;
        for (let i = 0; i < array.length; i++) {
            if (array[i].valoare < min) min = array[i].valoare;
        }
        // max+=10-max%10;
    }
    return min;
}

function getXPoint(value, data) {
    return ((canvas.width - xDistance) / data.length) * value + xDistance * 1.5;
}

function getYPoint(value, array) {
    return (
        canvas.height -
        ((canvas.height - yDistance) / (getMaxValue(array) - getMinValue(array))) *
        (value - getMinValue(array)) -
        yDistance
    );
}

function initBubbleChart() {
    let graphData = initializeLieGraph(countriesData);
    let max = getMaxValue(graphData);

    //Initializing graph axis
    canvas = document.getElementById("graphCanvas");
    canvas.style.display="block";
    let ctx = canvas.getContext("2d");

    ctx.clearRect(0, 0, canvas.width + 100, canvas.height + 100);
    ctx.font = "20px serif";
    ctx.textAlign = "center";
    ctx.fillStyle = "black";
    ctx.fillText(
        `Bubble chart for country ${graphData[0].tara}, Indicator: ${graphData[0].indicator}`,
        canvas.width / 2 - 80,
        yDistance + 20
    );

    ctx.lineWidth = 2;
    ctx.strokeStyle = "#454545";
    ctx.font = "8pt serif";
    ctx.textAlign = "center";
    ctx.fillStyle = "black";
    ctx.beginPath();
    ctx.moveTo(xDistance, 0);
    ctx.lineTo(xDistance, canvas.height - yDistance);
    ctx.lineTo(canvas.width, canvas.height - yDistance);
    ctx.stroke();

    //Fill x axis
    for (let i = 0; i < graphData.length; i++) {
        ctx.fillText(
            graphData[i].an,
            getXPoint(i, graphData) + 10,
            canvas.height - yDistance + 20
        );
    }

    //Fill y axis
    ctx.textAlign = "right";
    ctx.textBaseline = "middle";
    for (
        let i = getMinValue(graphData), j = canvas.height - 30;
        i <= getMaxValue(graphData);
        i += (getMaxValue(graphData) - getMinValue(graphData)) / 10,
            j -= canvas.height / 10
    ) {
        ctx.fillText(i.toFixed(2), xDistance, j);
    }

    //Draw points
    for (let i = 0; i < graphData.length; i++) {
        (function (index) {
            setTimeout(function () {
                //Random color for every dot
                const color = Math.floor(Math.random() * 16777215).toString(16);
                ctx.fillStyle = "#" + color;
                ctx.beginPath();
                let radius =
                    (20 *
                        (canvas.height -
                            yDistance -
                            getYPoint(graphData[i].valoare, graphData))) /
                    (canvas.height - yDistance);
                ctx.arc(
                    getXPoint(i, graphData),
                    getYPoint(graphData[i].valoare, graphData),
                    3 + radius,
                    0,
                    Math.PI * 2,
                    true
                );
                ctx.fill();
            }, 200 * i);
        })(i);
    }
}

function drawBubbleChart() {
    initBubbleChart();
}

// CREATING SVG CHART FUNCTIONS

//SVG CHART

function getSVGXPoint(value, data) {
    return ((width - xDistance) / data.length) * value + xDistance;
}

function getSVGYPoint(value, array) {
    return (
        height -
        ((height - yDistance) / (getMaxValue(array) - getMinValue(array))) *
        (value - getMinValue(array)) -
        yDistance
    );
}

function initSvgChart() {
    let graphData = initializeLieGraph(countriesData);
    svg = document.getElementById("svgGraphContainer");
    svg.style.display = "block";
    let title = document.createTextNode(
        `Grafic pentru tara ${countriesData[0].tara}`
    );
    svg.appendChild(title);
    console.log("SVG:", graphData);
    let xAxis = "";
    let yAxis = "";
    let graphLine = "";
    let graphPoints = "";
    //Fill x axis
    for (let i = 0; i < graphData.length; i++) {
        xAxis +=
            "<text font-size='10px' x=\"" +
            (getSVGXPoint(i, graphData) + 25) +
            '" y="' +
            (height - yDistance + 20) +
            '"> ' +
            graphData[i].an +
            " </text>";
    }

    //Fill y axis
    for (
        let i = getMinValue(graphData), j = height - 30;
        i <= getMaxValue(graphData);
        i += (getMaxValue(graphData) - getMinValue(graphData)) / 10,
            j -= height / 10
    ) {
        yAxis +=
            "<text font-size='10px' x=\"" +
            (xDistance - 50) +
            '" y="' +
            j +
            '"> ' +
            i.toFixed(2) +
            " </text>";
    }

    //Draw line graph
    graphLine =
        getSVGXPoint(0, graphData) +
        30 +
        "," +
        getSVGYPoint(graphData[0].valoare, graphData) +
        " ";
    for (let i = 0; i < graphData.length; i++) {
        graphLine +=
            getSVGXPoint(i, graphData) +
            30 +
            "," +
            getSVGYPoint(graphData[i].valoare, graphData) +
            " ";
    }

    //Draw points
    for (let i = 0; i < graphData.length; i++) {
        let pointData = getDataByYearAndCountry(graphData[i].an, graphData[i].tara);
        graphPoints +=
            "<circle fill='red' cx=\"" +
            (getSVGXPoint(i, graphData) + 30) +
            '" cy="' +
            getSVGYPoint(graphData[i].valoare, graphData) +
            '" r=4 >' +
            "<title>" +
            "Tara: " +
            pointData[0].tara +
            "\n An: " +
            pointData[0].an +
            "\n Indicator: " +
            pointData[0].indicator +
            " Valoare: " +
            pointData[0].valoare +
            "\n Indicator: " +
            pointData[1].indicator +
            " Valoare: " +
            pointData[1].valoare +
            "\n Indicator: " +
            pointData[2].indicator +
            " Valoare: " +
            pointData[2].valoare +
            "</title> " +
            "</circle>";
    }

    svg.innerHTML = `<g class="svgChart x-axis">
        <line stroke="black" stroke-width="3" x1=${xDistance} x2=${xDistance} y1=${yDistance} y2=${
        height - yDistance
    }></line> 
        <line stroke="black" stroke-width="3" x1=${xDistance} x2=${width} y1=${
        height - yDistance
    } y2=${height - yDistance}></line>
    </g>

        <g class="svgChart x-Labels">
        ${xAxis}
        </g>
        <g class="svgChart y-Labels">
        ${yAxis}
        </g>
        <text font-size="20px" x="${width / 2 - 80}" y="${
        yDistance + 20
    }">SVG graph for country ${graphData[0].tara}, Indicator: ${
        graphData[0].indicator
    }</text> 
        <polyline
        class="svgChart line"
        fill="none"
        stroke-width="3"
        stroke="black"
        points="${graphLine}"
        />
        <g class="svgChart points">
        ${graphPoints}
        </g>

    `;
}

function drawSvgChart() {
    initSvgChart();
}
