package ro.ase.ppoo;

public interface ICalculeazaRata {

    float calculeazaRata(String numeBanca);
}
