package exceptii;

public class ExceptieCustom  extends Exception{
	
	public ExceptieCustom(String mesaj) {
		super(mesaj);
	}

}
