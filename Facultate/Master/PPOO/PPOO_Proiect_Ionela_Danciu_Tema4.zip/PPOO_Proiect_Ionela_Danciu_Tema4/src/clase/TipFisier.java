package clase;

public enum TipFisier {
	
	mp3, mp4, jpg, png;
}
